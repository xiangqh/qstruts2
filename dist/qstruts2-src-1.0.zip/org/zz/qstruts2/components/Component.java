package org.zz.qstruts2.components;

/**
 * @author xiangqh
 *
 */
public abstract class Component {

}
